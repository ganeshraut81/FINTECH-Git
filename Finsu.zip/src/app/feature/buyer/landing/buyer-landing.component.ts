import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-buyer-landing',
  templateUrl: './buyer-landing.component.html',
  styleUrls: ['./buyer-landing.component.scss']
})
export class BuyerLandingComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
