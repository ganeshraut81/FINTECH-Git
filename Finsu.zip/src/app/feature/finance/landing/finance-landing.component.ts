import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-finance-landing',
  templateUrl: './finance-landing.component.html',
  styleUrls: ['./finance-landing.component.scss']
})
export class FinanceLandingComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
