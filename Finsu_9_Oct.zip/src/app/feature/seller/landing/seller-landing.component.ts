import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-seller-landing',
  templateUrl: './seller-landing.component.html',
  styleUrls: ['./seller-landing.component.scss']
})
export class SellerLandingComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
