import { Component, OnInit } from '@angular/core';
import { ProductsService } from 'src/app/core/service/products.service';

@Component({
  selector: 'app-logistics-landing',
  templateUrl: './logistics-landing.component.html',
  styleUrls: ['./logistics-landing.component.scss']
})
export class LogisticsLandingComponent implements OnInit {

  products: any;

  constructor(private productsService: ProductsService) { }

  ngOnInit() {
    this.productsService.newArrivalProducts().subscribe(
      data => {
        this.products = data['products'];
        //console.log(`Product array :${JSON.stringify(this.products)}`);
      }
    )
  }

}
