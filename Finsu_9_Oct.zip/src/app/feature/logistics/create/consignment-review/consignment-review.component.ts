import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-consignment-review',
  templateUrl: './consignment-review.component.html',
  styleUrls: ['./consignment-review.component.scss']
})
export class ConsignmentReviewComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
