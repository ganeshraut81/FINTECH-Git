import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-saved-shipping-detail',
  templateUrl: './saved-shipping-detail.component.html',
  styleUrls: ['./saved-shipping-detail.component.scss']
})
export class SavedShippingDetailComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
