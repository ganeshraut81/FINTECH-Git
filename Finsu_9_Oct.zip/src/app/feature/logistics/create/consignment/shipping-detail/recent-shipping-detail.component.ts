import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-recent-shipping-detail',
  templateUrl: './recent-shipping-detail.component.html',
  styleUrls: ['./recent-shipping-detail.component.scss']
})
export class RecentShippingDetailComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
