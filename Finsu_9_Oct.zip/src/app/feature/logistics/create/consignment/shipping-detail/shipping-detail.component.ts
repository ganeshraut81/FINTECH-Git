import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-shipping-detail',
  templateUrl: './shipping-detail.component.html',
  styleUrls: ['./shipping-detail.component.scss']
})
export class ShippingDetailComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
