import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-packing-detail',
  templateUrl: './packing-detail.component.html',
  styleUrls: ['./packing-detail.component.scss']
})
export class PackingDetailComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
