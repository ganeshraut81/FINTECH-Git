import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-saved-packing-detail',
  templateUrl: './saved-packing-detail.component.html',
  styleUrls: ['./saved-packing-detail.component.scss']
})
export class SavedPackingDetailComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
