import { AdminComponent } from './admin.component';
import { Component } from '@angular/core';
import { Route } from '@angular/router';

export const adminRoutes: Route[] = [
    {
        path: '',
        component: AdminComponent
    }];

